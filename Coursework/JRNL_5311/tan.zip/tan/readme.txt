Github link: https://benzhtan.github.io/Coursework/JRNL_5311/tan/index.html
